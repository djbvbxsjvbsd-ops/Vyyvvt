package com.valdoria.rpg.client;

import com.valdoria.rpg.client.screen.UITheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.client.gui.overlay.ForgeGui;

public class HudOverlay {

    private static final int MARGIN  = 4;
    private static final int PANEL_W = 102;
    private static final int PANEL_H = 84;
    private static final int BAR_H   = 5;

    public void render(ForgeGui gui, GuiGraphics g,
                       float partialTick, int screenW, int screenH) {

        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui)        return;
        if (!ClientData.hudVisible)    return;

        LocalPlayer player = mc.player;
        if (player == null)            return;

        // Auto-scale so HUD fits tiny screens
        float scale = Math.min(1.0F, Math.min(screenW, screenH) / 320.0F);
        int   pw    = (int)(PANEL_W * scale);
        int   ph    = (int)(PANEL_H * scale);
        int   px    = MARGIN;
        int   py    = MARGIN;

        long time = System.currentTimeMillis();

        // Background + animated border
        g.fill(px, py, px + pw, py + ph, UITheme.getBgColor());
        UITheme.renderBorder(g, px, py, pw, ph, time);

        // Snow overlay in Niveria
        if (ClientData.inNiveria)
            UITheme.renderSnow(g, px + 1, py + 1, pw - 2, ph - 2);

        // Scale inner content
        var pose = g.pose();
        pose.pushPose();
        pose.translate(px, py, 0);
        pose.scale(scale, scale, 1.0F);

        renderContent(g, mc, player, time);

        pose.popPose();
    }

    private void renderContent(GuiGraphics g, Minecraft mc,
                               LocalPlayer player, long time) {
        int cx = 2;
        int cy = 4;

        // ── Mini 3-D avatar ───────────────────────────────────────────────
        int avCX = cx + 13;
        int avY0 = cy;
        int avY1 = cy + 26;
        InventoryScreen.renderEntityInInventoryFollowsMouse(
                g,
                avCX - 11, avY0,
                avCX + 11, avY1,
                14, 0.0625F,
                avCX, avY1 - 10,
                player);

        // ── Name + level ──────────────────────────────────────────────────
        int nameX = cx + 28;
        g.drawString(mc.font,
                "ENZO * LV." + player.experienceLevel,
                nameX, cy + 2,
                UITheme.getBorderColorBase(), true);

        // ── Tag ───────────────────────────────────────────────────────────
        cy += 12;
        String tag;
        int    tagCol;
        if (ClientData.inNiveria) { tag = "* FRIO"; tagCol = 0xFF00E5FF; }
        else { tag = ClientData.factionName(); tagCol = UITheme.getBorderColorBase(); }
        g.drawString(mc.font, tag, nameX, cy + 2, tagCol, false);

        // ── Bars ──────────────────────────────────────────────────────────
        cy += 14;
        int barX = cx + 28;
        int barW = PANEL_W - barX - 4;

        float maxHp = player.getMaxHealth();
        float curHp = player.getHealth();
        drawMiniBar(g, mc, barX, cy, barW, BAR_H,
                curHp, maxHp, String.format("HP %.0f", curHp), UITheme.hpColor());
        cy += BAR_H + 6;

        drawMiniBar(g, mc, barX, cy, barW, BAR_H,
                ClientData.mana, ClientData.maxMana,
                String.format("MP %.0f", ClientData.mana), UITheme.manaColor());
        cy += BAR_H + 6;

        drawMiniBar(g, mc, barX, cy, barW, BAR_H,
                player.experienceProgress, 1.0F,
                "XP", UITheme.xpColor());
        cy += BAR_H + 6;

        // ── Quest counter ──────────────────────────────────────────────────
        g.drawString(mc.font,
                "Quest " + ClientData.completed + "/101",
                cx + 2, cy + 2, UITheme.questColor(), false);

        // ── Fragmentos (Niveria only) ──────────────────────────────────────
        if (ClientData.inNiveria) {
            cy += 10;
            g.drawString(mc.font,
                    "Frags: " + ClientData.fragmentosGlaciais,
                    cx + 2, cy + 2, 0xFF00E5FF, false);
        }
    }

    private void drawMiniBar(GuiGraphics g, Minecraft mc,
            int x, int y, int w, int h,
            float cur, float max, String label, int color) {
        float frac   = max <= 0 ? 0 : Math.min(1, cur / max);
        int   filled = (int)(w * frac);
        g.fill(x, y, x + w, y + h, 0x55000000);
        if (filled > 0) g.fill(x, y, x + filled, y + h, color);
        int lw = mc.font.width(label);
        g.drawString(mc.font, label, x - lw - 2, y - 1, 0xFFFFFFFF, false);
    }
}
