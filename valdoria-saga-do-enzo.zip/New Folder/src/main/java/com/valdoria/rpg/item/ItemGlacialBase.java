// [ItemGlacialBase.java]
package com.valdoria.rpg.item;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import java.util.List;
public class ItemGlacialBase extends Item {
    private final String tooltip;
    public ItemGlacialBase(Properties props, String tooltip) {
        super(props);
        this.tooltip = tooltip;
    }
    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltips, TooltipFlag flag) {
        tooltips.add(Component.literal("§b" + tooltip));
    }
}
