// [QuestManager.java] — SUBSTITUI o original; suporte a 101 missões
package com.valdoria.rpg.quest;
import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.network.ModNetwork;
import com.valdoria.rpg.network.OpenFactionPacket;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
public final class QuestManager {
    private QuestManager() {}
    public static void give(ServerPlayer p, ItemStack st) {
        if (!p.getInventory().add(st)) p.drop(st, false);
    }
    public static int count(ServerPlayer p, String itemId) {
        int n = 0;
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && itemId.equals(BuiltInRegistries.ITEM.getKey(s.getItem()).toString())) n += s.getCount();
        }
        return n;
    }
    public static boolean isMet(ServerPlayer p, Quest q) {
        return switch (q.type()) {
            case HAVE -> count(p, q.target()) >= q.amount();
            case KILL -> PlayerData.getKills(p, q.target()) >= q.amount();
            case DIM -> p.level().dimension().location().toString().equals(q.target());
            case FACTION -> PlayerData.getFaction(p) != 0;
            case FLAG -> PlayerData.hasFlag(p, q.target());
        };
    }
    public static void tick(ServerPlayer p) {
        int done = PlayerData.getCompleted(p);
        boolean changed = false;
        while (done < QuestData.size()) {
            Quest q = QuestData.get(done + 1);
            if (!isMet(p, q)) break;
            complete(p, q);
            done++;
            changed = true;
        }
        if (changed) ModNetwork.sync(p);
    }
    public static void complete(ServerPlayer p, Quest q) {
        PlayerData.setCompleted(p, q.id());
        give(p, makeBook(q));
        if (q.reward() != null) q.reward().accept(p);
        p.sendSystemMessage(Component.literal("§6✦ Missão " + q.id() + "/101 concluída: §f" + q.title()));
        p.sendSystemMessage(Component.literal("§7Você recebeu o livro: Saga do Enzo Vol. " + q.id()));
        p.playSound(SoundEvents.PLAYER_LEVELUP, 1.0F, 1.0F);
        if (q.id() % 10 == 0 && q.id() < 101) {
            int nextAct = q.id() / 10 + 1;
            if (nextAct <= QuestData.ACT_NAMES.length) {
                p.sendSystemMessage(Component.literal("§e§l" + QuestData.ACT_NAMES[nextAct - 1] + " começa!"));
            }
        }
        if (q.id() == 49) {
            p.sendSystemMessage(Component.literal("§c§lMALACHAR DESPERTOU. Vá ao castelo e derrote-o."));
        }
        if (q.id() == 50) {
            p.sendSystemMessage(Component.literal("§6§lMALACHAR FOI DERROTADO. O portal para Nivéria se abriu."));
            com.valdoria.rpg.entity.EnzoGlacial.spawnNear(p);
        }
        if (q.id() == 10 && PlayerData.getFaction(p) == 0) {
            ModNetwork.sendTo(p, new OpenFactionPacket());
        }
    }
    public static ItemStack makeBook(Quest q) {
        ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
        CompoundTag tag = book.getOrCreateTag();
        tag.putString("title", "Saga do Enzo Vol. " + q.id());
        tag.putString("author", "Rei Aldric");
        ListTag pages = new ListTag();
        String page1 = QuestData.actName(q.act()) + "\n\nVol. " + q.id() + ": " + q.title() + "\n\n" + q.lore();
        pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(page1))));
        tag.put("pages", pages);
        tag.putBoolean("resolved", true);
        return book;
    }
}
