package com.valdoria.rpg.client.screen;

import com.valdoria.rpg.client.ClientData;
import com.valdoria.rpg.client.KeyMappings;
import com.valdoria.rpg.quest.Quest;
import com.valdoria.rpg.quest.QuestData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;

import java.util.ArrayList;
import java.util.List;

public class ProfileScreen extends Screen {

    // ── Tabs ──────────────────────────────────────────────────────────────
    private static final int TAB_PROFILE = 0;
    private static final int TAB_ACH     = 1;
    private int activeTab = TAB_PROFILE;

    // ── Panel geometry ────────────────────────────────────────────────────
    private int panelX, panelY;
    private static final int PANEL_W = 240;
    private static final int PANEL_H = 220;
    private static final int TAB_H   = 14;

    // ── Tooltip hover flags ───────────────────────────────────────────────
    private boolean hoverMana   = false;
    private boolean hoverAvatar = false;

    // ── Achievement list ──────────────────────────────────────────────────
    private record AchEntry(String label, boolean done) {}
    private final List<AchEntry> achievements = new ArrayList<>();

    public ProfileScreen() {
        super(Component.literal("Perfil"));
    }

    @Override
    protected void init() {
        super.init();
        panelX = (width  - PANEL_W) / 2;
        panelY = (height - PANEL_H) / 2;

        achievements.clear();
        int total = QuestData.size();
        for (int i = 0; i < total; i++) {
            Quest q    = QuestData.get(i);
            boolean ok = (i < ClientData.completed);
            achievements.add(new AchEntry(q.title, ok));
        }

        // ── PARTE 4: som ao abrir ─────────────────────────────────────────
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null)
            mc.player.playSound(SoundEvents.BOOK_PAGE_TURN.value(), 0.5F, 1.0F);
    }

    @Override
    public void onClose() {
        // ── PARTE 4: som ao fechar ────────────────────────────────────────
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null)
            mc.player.playSound(SoundEvents.BOOK_PAGE_TURN.value(), 0.5F, 0.9F);
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() { return false; }

    // ── Main render ───────────────────────────────────────────────────────
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        long time = System.currentTimeMillis();

        UITheme.renderPanel(g, panelX, panelY, PANEL_W, PANEL_H, time);

        if (ClientData.inNiveria)
            UITheme.renderSnow(g, panelX + 1, panelY + 1, PANEL_W - 2, PANEL_H - 2);

        renderTabs(g, time);

        if (activeTab == TAB_PROFILE) renderProfileTab(g, mouseX, mouseY, partialTick);
        else                          renderAchTab(g);

        renderTooltips(g, mouseX, mouseY);
        super.render(g, mouseX, mouseY, partialTick);
    }

    // ── Tabs ──────────────────────────────────────────────────────────────
    private void renderTabs(GuiGraphics g, long time) {
        String[] labels = { "PERFIL", "CONQUISTAS" };
        int tw = PANEL_W / labels.length;

        for (int i = 0; i < labels.length; i++) {
            int tx = panelX + i * tw;
            int ty = panelY;
            boolean active = (i == activeTab);

            int bg = active
                ? (0x99000000 | (UITheme.getBorderColorBase() & 0x00FFFFFF))
                : 0x44000000;
            g.fill(tx, ty, tx + tw, ty + TAB_H, bg);

            if (active)
                g.fill(tx, ty + TAB_H - 1, tx + tw, ty + TAB_H,
                        UITheme.getAnimatedBorderColor(time));

            int textW = font.width(labels[i]);
            g.drawString(font, labels[i],
                    tx + (tw - textW) / 2, ty + 3, 0xFFFFFFFF, true);
        }
    }

    // ── Profile tab ───────────────────────────────────────────────────────
    private void renderProfileTab(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        Minecraft   mc = Minecraft.getInstance();
        LocalPlayer pl = mc.player;

        int contentY = panelY + TAB_H + 2;
        int cx       = panelX + 4;

        // Title
        String title = "PERFIL DE ENZO";
        g.drawString(font, title,
                panelX + (PANEL_W - font.width(title)) / 2,
                contentY + 2, UITheme.getBorderColorBase(), true);

        // ── 3-D Avatar ────────────────────────────────────────────────────
        int avX  = panelX + 36;
        int avY0 = contentY + 20;
        int avY1 = contentY + 68;
        hoverAvatar = (mouseX >= avX - 18 && mouseX <= avX + 18
                && mouseY >= avY0 && mouseY <= avY1);

        if (pl != null) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(
                    g, avX - 18, avY0, avX + 18, avY1,
                    28, 0.0625F, mouseX, mouseY, pl);
        }

        // ── Stat bars ─────────────────────────────────────────────────────
        int barX = panelX + 82;
        int barW = PANEL_W - barX + panelX - 4;
        int cy   = contentY + 22;
        int barH = 7;

        if (pl != null) {
            float maxHp = pl.getMaxHealth();
            float curHp = pl.getHealth();
            drawLabeledBar(g, barX, cy, barW, barH,
                    curHp, maxHp,
                    String.format("HP %.0f/%.0f", curHp, maxHp),
                    UITheme.hpColor());
            cy += 18;

            int food = pl.getFoodData().getFoodLevel();
            drawLabeledBar(g, barX, cy, barW, barH,
                    food, 20,
                    "Fome " + food + "/20",
                    UITheme.foodColor());
            cy += 18;

            drawLabeledBar(g, barX, cy, barW, barH,
                    pl.experienceProgress, 1.0F,
                    "XP Nv " + pl.experienceLevel,
                    UITheme.xpColor());
            cy += 18;

            // Mana – hover detection
            int manaY = cy;
            hoverMana = (mouseX >= barX && mouseX <= barX + barW
                    && mouseY >= manaY && mouseY <= manaY + barH + 9);
            drawLabeledBar(g, barX, manaY, barW, barH,
                    ClientData.mana, ClientData.maxMana,
                    String.format("Mana %.0f/%.0f", ClientData.mana, ClientData.maxMana),
                    UITheme.manaColor());
            cy += 18;
        }

        // ── Extra info ────────────────────────────────────────────────────
        cy = contentY + 108;
        g.drawString(font, "Faccao: "   + ClientData.factionName(),   cx, cy,      0xFFFFFFFF, false); cy += 10;
        g.drawString(font, "Dimensao: " + ClientData.dimensionName(), cx, cy,      0xFFCCCCCC, false); cy += 10;

        if (ClientData.inNiveria) {
            g.drawString(font, "Fragmentos Glaciais: " + ClientData.fragmentosGlaciais,
                    cx, cy, 0xFF00E5FF, false);
            cy += 10;
        }

        if (pl != null && !pl.getActiveEffects().isEmpty()) {
            g.drawString(font, "Efeitos:", cx, cy, 0xFFAAFFAA, false); cy += 10;
            for (MobEffectInstance eff : pl.getActiveEffects()) {
                g.drawString(font, " * " + eff.getEffect().getDisplayName().getString(),
                        cx, cy, 0xFFFFFFAA, false);
                cy += 9;
            }
        }

        // ── Quest progress bar (footer) ───────────────────────────────────
        int bx = panelX + 4;
        int by = panelY + PANEL_H - 18;
        int bw = PANEL_W - 8;
        int bh = 8;
        float frac   = ClientData.completed <= 0 ? 0 : (float) ClientData.completed / 101;
        int   filled = (int)(bw * frac);
        g.fill(bx, by, bx + bw, by + bh, 0x66000000);
        if (filled > 0) g.fill(bx, by, bx + filled, by + bh, UITheme.questColor());
        g.fill(bx, by, bx + bw, by + 1, 0xFFFFFFFF);
        g.fill(bx, by + bh - 1, bx + bw, by + bh, 0xFFFFFFFF);
        g.fill(bx, by, bx + 1, by + bh, 0xFFFFFFFF);
        g.fill(bx + bw - 1, by, bx + bw, by + bh, 0xFFFFFFFF);
        String ql = "Quest " + ClientData.completed + "/101";
        g.drawString(font, ql, bx + (bw - font.width(ql)) / 2, by - 9, 0xFFFFFFFF, true);
    }

    // ── Achievements tab ──────────────────────────────────────────────────
    private void renderAchTab(GuiGraphics g) {
        int sy = panelY + TAB_H + 6;
        String hdr = "CONQUISTAS";
        g.drawString(font, hdr, panelX + (PANEL_W - font.width(hdr)) / 2,
                sy, UITheme.getBorderColorBase(), true);
        sy += 12;

        int rowH     = 11;
        int maxVis   = (PANEL_H - TAB_H - 20) / rowH;
        int cx       = panelX + 6;

        for (int i = 0; i < Math.min(achievements.size(), maxVis); i++) {
            AchEntry e   = achievements.get(i);
            String   sym = e.done() ? "v " : "x ";
            int      col = e.done() ? UITheme.tickColor() : UITheme.crossColor();
            g.drawString(font, sym + e.label(), cx, sy + i * rowH, col, false);
        }
    }

    // ── Bar helper ────────────────────────────────────────────────────────
    private void drawLabeledBar(GuiGraphics g,
            int x, int y, int w, int h,
            float cur, float max, String label, int color) {
        float frac   = max <= 0 ? 0 : Math.min(1, cur / max);
        int   filled = (int)(w * frac);
        g.fill(x, y, x + w, y + h, 0x44000000);
        if (filled > 0) g.fill(x, y, x + filled, y + h, color);
        g.drawString(font, label, x, y + h + 1, 0xFFFFFFFF, false);
    }

    // ── Tooltips ──────────────────────────────────────────────────────────
    private void renderTooltips(GuiGraphics g, int mouseX, int mouseY) {
        if (activeTab != TAB_PROFILE) return;
        if (hoverMana)
            g.renderTooltip(font, Component.literal("Regen: +2/s"), mouseX, mouseY);
        else if (hoverAvatar)
            g.renderTooltip(font, Component.literal("Enzo, o Escolhido"), mouseX, mouseY);
    }

    // ── Mouse click ───────────────────────────────────────────────────────
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int tw = PANEL_W / 2;
        // Tab 0
        if (mouseX >= panelX && mouseX < panelX + tw
                && mouseY >= panelY && mouseY < panelY + TAB_H) {
            if (activeTab != TAB_PROFILE) { activeTab = TAB_PROFILE; playTabSound(); }
            return true;
        }
        // Tab 1
        if (mouseX >= panelX + tw && mouseX < panelX + PANEL_W
                && mouseY >= panelY && mouseY < panelY + TAB_H) {
            if (activeTab != TAB_ACH) { activeTab = TAB_ACH; playTabSound(); }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    // ── PARTE 4: som ao trocar aba ────────────────────────────────────────
    private void playTabSound() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null)
            mc.player.playSound(SoundEvents.UI_BUTTON_CLICK.value(), 0.5F, 1.0F);
    }

    // ── Close on P or ESC ─────────────────────────────────────────────────
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (KeyMappings.PROFILE.isActiveAndMatches(
                net.minecraft.client.KeyMapping.click(keyCode))) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
