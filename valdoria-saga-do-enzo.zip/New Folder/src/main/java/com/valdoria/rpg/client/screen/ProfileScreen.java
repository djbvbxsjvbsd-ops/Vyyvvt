// [ProfileScreen.java] — SUBSTITUI o original; adiciona progresso parcial, dimensão e debuffs
package com.valdoria.rpg.client.screen;
import com.valdoria.rpg.client.ClientData;
import com.valdoria.rpg.client.KeyMappings;
import com.valdoria.rpg.quest.Quest;
import com.valdoria.rpg.quest.QuestData;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import java.util.Collection;
public class ProfileScreen extends Screen {
    public ProfileScreen() { super(Component.literal("Perfil")); }
    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int w = 290, h = 210, x = width / 2 - w / 2, y = height / 2 - h / 2;
        g.fillGradient(x, y, x + w, y + h, 0xEE1B1B2A, 0xEE0A0A12);
        g.renderOutline(x, y, w, h, ClientData.inNiveria ? 0xFF4488FF : 0xFFB8860B);
        g.drawCenteredString(font, "§6§lPERFIL DE ENZO", width / 2, y + 8, 0xFFFFFF);
        LocalPlayer p = minecraft.player;
        if (p != null) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(g, x + 45, y + 150, 50, (float) mx, (float) my, p);
            int tx = x + 100, ty = y + 22;
            g.drawString(font, "Nome: " + p.getName().getString(), tx, ty, 0xFFFFFF, false);
            g.drawString(font, "Facção: " + ClientData.factionName(), tx, ty + 12, 0xFFFFFF, false);
            g.drawString(font, "Ato: " + QuestData.actName(ClientData.act()), tx, ty + 24, 0xFFD54F, false);
            g.drawString(font, "Missões: " + ClientData.completed + "/101", tx, ty + 36, 0xFFFFFF, false);
            g.drawString(font, String.format("HP %.0f/%.0f", p.getHealth(), p.getMaxHealth()), tx, ty + 48, 0xFF6666, false);
            g.drawString(font, String.format("Mana %.0f/%.0f", ClientData.mana, ClientData.maxMana), tx, ty + 60, 0x66AAFF, false);
            g.drawString(font, "Nível XP: " + p.experienceLevel, tx, ty + 72, 0x88FF88, false);
            g.drawString(font, "Dimensão: " + ClientData.dimensionName(), tx, ty + 84, ClientData.inNiveria ? 0xFF88CCFF : 0xAAFFAA, false);
            if (ClientData.inNiveria) {
                g.drawString(font, "❄ Fragmentos Glaciais: " + ClientData.fragmentosGlaciais, tx, ty + 96, 0xFF88CCFF, false);
            }
            Collection<MobEffectInstance> effects = p.getActiveEffects();
            if (!effects.isEmpty()) {
                int ey = ty + 108;
                g.drawString(font, "§7Efeitos:", tx, ey, 0xFFFFFF, false);
                ey += 10;
                for (MobEffectInstance ef : effects) {
                    String name = ef.getEffect().getDisplayName().getString();
                    g.drawString(font, "§c• " + name, tx, ey, 0xFFFFFF, false);
                    ey += 10;
                    if (ey > y + h - 20) break;
                }
            }
            if (ClientData.completed < QuestData.size()) {
                Quest q = QuestData.get(ClientData.completed + 1);
                int qy = y + h - 50;
                g.drawString(font, "§7Missão: §f" + q.title(), x + 10, qy, 0xFFFFFF, false);
                g.drawString(font, "§7" + q.objective(), x + 10, qy + 12, 0xFFFFFF, false);
            } else {
                g.drawString(font, "§6Saga completa!", x + 10, y + h - 40, 0xFFFFFF, false);
            }
        }
        super.render(g, mx, my, pt);
    }
    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (KeyMappings.PROFILE.matches(key, scan)) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }
    @Override public boolean isPauseScreen() { return false; }
}
