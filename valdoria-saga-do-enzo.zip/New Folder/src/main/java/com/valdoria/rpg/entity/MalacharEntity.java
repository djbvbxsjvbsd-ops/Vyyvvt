package com.valdoria.rpg.entity;

import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Enzo Demoníaco (Malachar): 500 HP. Fase 2 = invulnerável + 4 cristais. Fase 3 = fogo e velocidade. */
public class MalacharEntity extends Zombie {
    private static final UUID RAGE_SPEED = UUID.fromString("5b0c9a9e-6a0a-4a8e-9b53-3a5f3c8d1e11");

    private final ServerBossEvent bossBar = new ServerBossEvent(
            Component.literal("Enzo Demoníaco"), BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_10);
    private final List<UUID> crystals = new ArrayList<>();
    private int phase = 1;

    public MalacharEntity(EntityType<? extends MalacharEntity> type, Level level) {
        super(type, level);
        this.xpReward = 500;
        this.setCustomName(Component.literal("Enzo Demoníaco"));
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 500.0D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.ARMOR, 10.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.FOLLOW_RANGE, 64.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.SPAWN_REINFORCEMENTS_CHANCE, 0.0D);
    }

    public static MalacharEntity spawnNear(ServerPlayer p) {
        ServerLevel lvl = p.serverLevel();
        MalacharEntity m = ModEntities.MALACHAR.get().create(lvl);
        if (m == null) return null;
        m.moveTo(p.getX() + 6.0D, p.getY(), p.getZ(), 0.0F, 0.0F);
        m.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
        m.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        m.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
        m.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        m.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
        m.setTarget(p);
        lvl.addFreshEntity(m);
        m.playSound(SoundEvents.WITHER_SPAWN, 1.0F, 0.7F);
        return m;
    }

    @Override protected boolean isSunSensitive() { return false; }
    @Override protected boolean convertsInWater() { return false; }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossBar.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossBar.removePlayer(player);
    }

    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (phase == 2 && !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY) && crystalsAlive()) return false;
        return super.hurt(src, amount);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean r = super.doHurtTarget(target);
        if (r && phase == 3) target.setSecondsOnFire(8);
        return r;
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        float pct = getHealth() / getMaxHealth();
        bossBar.setProgress(pct);
        if (phase < 1) phase = 1;
        if (phase == 1 && pct <= 0.6F) startPhase2();
        else if (phase == 2 && !crystalsAlive()) startPhase3();
        if (phase == 3) {
            ensureRage();
            if (tickCount % 40 == 0) flameBurst();
        }
    }

    private void startPhase2() {
        phase = 2;
        crystals.clear();
        int[][] offsets = {{6, 0}, {-6, 0}, {0, 6}, {0, -6}};
        for (int[] o : offsets) {
            EndCrystal c = new EndCrystal(level(), getX() + o[0], getY(), getZ() + o[1]);
            c.setShowBottom(false);
            level().addFreshEntity(c);
            crystals.add(c.getUUID());
        }
        bossBar.setName(Component.literal("Enzo Demoníaco - Destrua os Cristais!"));
        playSound(SoundEvents.ENDER_DRAGON_GROWL, 1.0F, 0.8F);
    }

    private void startPhase3() {
        phase = 3;
        bossBar.setName(Component.literal("Enzo Demoníaco - FÚRIA"));
        ensureRage();
        playSound(SoundEvents.BLAZE_SHOOT, 1.0F, 0.6F);
    }

    private void ensureRage() {
        var attr = getAttribute(Attributes.MOVEMENT_SPEED);
        if (attr != null && attr.getModifier(RAGE_SPEED) == null) {
            attr.addTransientModifier(new AttributeModifier(RAGE_SPEED, "malachar_rage", 0.6D, AttributeModifier.Operation.MULTIPLY_TOTAL));
        }
    }

    private void flameBurst() {
        for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(8.0D))) {
            p.setSecondsOnFire(5);
        }
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.FLAME, getX(), getY() + 1.0D, getZ(), 40, 1.5D, 1.0D, 1.5D, 0.05D);
        }
    }

    private boolean crystalsAlive() {
        if (!(level() instanceof ServerLevel sl)) return false;
        for (UUID id : crystals) {
            Entity e = sl.getEntity(id);
            if (e != null && e.isAlive()) return true;
        }
        return false;
    }

    @Override
    public void die(DamageSource src) {
        super.die(src);
        if (level() instanceof ServerLevel sl) {
            for (ServerPlayer p : sl.players()) {
                if (p.distanceToSqr(this) < 120.0D * 120.0D) PlayerData.setFlag(p, "malachar_dead");
            }
            for (UUID id : crystals) {
                Entity e = sl.getEntity(id);
                if (e != null) e.discard();
            }
            bossBar.removeAllPlayers();
        }
    }

    public int getPhase() { return phase; }

    @Override
    public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("MalacharPhase", phase);
        ListTag list = new ListTag();
        for (UUID id : crystals) list.add(NbtUtils.createUUID(id));
        tag.put("MalacharCrystals", list);
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        phase = Math.max(1, tag.getInt("MalacharPhase"));
        crystals.clear();
        for (Tag t : tag.getList("MalacharCrystals", Tag.TAG_INT_ARRAY)) crystals.add(NbtUtils.loadUUID(t));
    }
}
