// [EspadaGlacial.java]
package com.valdoria.rpg.item;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import java.util.List;
public class EspadaGlacial extends SwordItem {
    public EspadaGlacial() {
        super(Tiers.DIAMOND, 8, -2.2F, new Properties().rarity(Rarity.EPIC));
    }
    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean r = super.hurtEnemy(stack, target, attacker);
        if (r && attacker instanceof Player p && !p.level().isClientSide) {
            for (LivingEntity e : p.level().getEntitiesOfClass(LivingEntity.class, target.getBoundingBox().inflate(4.0D))) {
                if (e != attacker) {
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 3));
                }
            }
        }
        return r;
    }
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack st = player.getItemInHand(hand);
        if (!player.getCooldowns().isOnCooldown(this)) {
            if (!level.isClientSide) {
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(4.0D))) {
                    if (e != player) e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 4));
                }
                player.sendSystemMessage(Component.literal("§b❄ Congelamento Glacial ativado!"));
            }
            player.getCooldowns().addCooldown(this, 200);
        }
        return InteractionResultHolder.sidedSuccess(st, level.isClientSide);
    }
    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltips, TooltipFlag flag) {
        tooltips.add(Component.literal("§bHabilidade: Congela inimigos em raio 4"));
        tooltips.add(Component.literal("§7Clique direito para congelar em área"));
    }
}
