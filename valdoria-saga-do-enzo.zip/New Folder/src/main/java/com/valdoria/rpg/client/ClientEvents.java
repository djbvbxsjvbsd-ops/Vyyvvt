package com.valdoria.rpg.client;

import com.valdoria.rpg.client.screen.MapScreen;
import com.valdoria.rpg.client.screen.ProfileScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "valdorianrpg", value = Dist.CLIENT)
public class ClientEvents {

    // campo original preservado
    private boolean coldFlicker = false;

    @SubscribeEvent
    public void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        // ── Tecla P → Perfil ──────────────────────────────────────────────
        if (KeyMappings.PROFILE.consumeClick()) {
            if (mc.screen == null) {
                // som tocado dentro de ProfileScreen.init()
                mc.setScreen(new ProfileScreen());
            }
        }

        // ── Tecla M → Mapa ────────────────────────────────────────────────
        if (KeyMappings.MAP.consumeClick()) {
            if (mc.screen == null) {
                // ── PARTE 4 SOM: abrir mapa ───────────────────────────────
                mc.player.playSound(SoundEvents.UI_BUTTON_CLICK.value(), 0.5F, 1.0F);
                mc.setScreen(new MapScreen());
            }
        }

        // ── Tecla H → Liga/desliga HUD ────────────────────────────────────
        if (KeyMappings.HUD.consumeClick()) {
            ClientData.hudVisible = !ClientData.hudVisible;
            // ── PARTE 4 SOM: toggle HUD ───────────────────────────────────
            mc.player.playSound(SoundEvents.LEVER_CLICK.value(), 0.5F, 1.0F);
        }

        // ── Lógica original de Niveria / frio (PRESERVADA) ───────────────
        // Detecta dimensão a cada tick (lógica original do mod)
        if (mc.level != null) {
            ResourceKey<Level> dim = mc.level.dimension();
            // inNiveria já é atualizado pelo SyncNiveriaPacket via servidor;
            // apenas mantemos a leitura de completed p/ efeito de nevasca.
            if (ClientData.inNiveria && ClientData.completed < 101) {
                // efeito de flicker de frio original (campo coldFlicker preservado)
                coldFlicker = !coldFlicker;
            }
        }
    }

    // ── Fog color – lógica original PRESERVADA ────────────────────────────
    @SubscribeEvent
    public void onFogColor(ViewportEvent.ComputeFogColor event) {
        if (ClientData.inNiveria) {
            event.setRed(0.333F);
            event.setGreen(0.533F);
            event.setBlue(0.733F);
        }
    }

    // ── HUD overlay – lógica original PRESERVADA ──────────────────────────
    @SubscribeEvent
    public void renderOverlay(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui) return;
        if (!ClientData.hudVisible) return;
        if (!ClientData.inNiveria) return;

        var g = event.getGuiGraphics();
        int sw = mc.getWindow().getGuiScaledWidth();
        // texto original " FRIO EXTREMO " no topo central
        g.drawCenteredString(mc.font, " FRIO EXTREMO ", sw / 2, 2, 0xFF00E5FF);
    }
}
