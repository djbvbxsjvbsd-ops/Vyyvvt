// [ClientEvents.java] — SUBSTITUI o original; adiciona overlay de frio de Nivéria
package com.valdoria.rpg.client;
import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.client.screen.MapScreen;
import com.valdoria.rpg.client.screen.ProfileScreen;
import com.valdoria.rpg.world.NiveriaDimension;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID, value = Dist.CLIENT)
public class ClientEvents {
    private static int coldFlicker = 0;
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        while (KeyMappings.PROFILE.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new ProfileScreen());
        }
        while (KeyMappings.MAP.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new MapScreen());
        }
        while (KeyMappings.HUD.consumeClick()) {
            ClientData.hudVisible = !ClientData.hudVisible;
        }
        coldFlicker++;
    }
    @SubscribeEvent
    public static void fog(ViewportEvent.ComputeFogColor e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        if (ClientData.completed >= 20 && ClientData.completed < 49 && mc.level.dimension() == Level.OVERWORLD) {
            e.setRed(0.70F); e.setGreen(0.05F); e.setBlue(0.05F);
        }
        if (ClientData.inNiveria) {
            e.setRed(0.65F); e.setGreen(0.80F); e.setBlue(0.95F);
        }
    }
    @SubscribeEvent
    public static void renderOverlay(RenderGuiOverlayEvent.Post e) {
        if (!ClientData.inNiveria) return;
        if (e.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        boolean visible = (coldFlicker / 20) % 2 == 0;
        if (visible) {
            e.getGuiGraphics().fill(0, 0, w, h, 0x22006680);
            e.getGuiGraphics().drawCenteredString(mc.font, "§b❄ FRIO EXTREMO ❄", w / 2, h / 2 - 60, 0xFF88CCFF);
        }
    }
}
