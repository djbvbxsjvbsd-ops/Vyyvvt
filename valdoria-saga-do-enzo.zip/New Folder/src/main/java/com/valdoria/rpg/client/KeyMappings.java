package com.valdoria.rpg.client;

import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public final class KeyMappings {
    public static final String CATEGORY = "key.categories.valdoria";
    public static final KeyMapping PROFILE = new KeyMapping("key.valdoria.profile", GLFW.GLFW_KEY_P, CATEGORY);
    public static final KeyMapping MAP = new KeyMapping("key.valdoria.map", GLFW.GLFW_KEY_M, CATEGORY);
    public static final KeyMapping HUD = new KeyMapping("key.valdoria.hud", GLFW.GLFW_KEY_H, CATEGORY);

    private KeyMappings() {}
}
