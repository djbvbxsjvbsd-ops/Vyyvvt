// [SyncNiveriaPacket.java]
package com.valdoria.rpg.network;
import com.valdoria.rpg.client.ClientData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
public class SyncNiveriaPacket {
    private final boolean inNiveria;
    private final int fragmentos;
    public SyncNiveriaPacket(boolean inNiveria, int fragmentos) {
        this.inNiveria = inNiveria;
        this.fragmentos = fragmentos;
    }
    public static void encode(SyncNiveriaPacket m, FriendlyByteBuf buf) {
        buf.writeBoolean(m.inNiveria);
        buf.writeInt(m.fragmentos);
    }
    public static SyncNiveriaPacket decode(FriendlyByteBuf buf) {
        return new SyncNiveriaPacket(buf.readBoolean(), buf.readInt());
    }
    public void handle(NetworkEvent.Context ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientData.updateNiveria(inNiveria, fragmentos));
    }
}
